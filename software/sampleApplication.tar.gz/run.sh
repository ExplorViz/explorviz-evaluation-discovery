#!/bin/sh
java -cp . -jar sampleApplication.jar
